#!/usr/bin/env python3
# Reference: https://github.com/yongan007/inverse_foward_kinematics_Kuka_iiwa/blob/master/FKinematics.m
import numpy as np
import math

def tf(DH):
    t=DH(0)
    d=DH(1)
    a=DH(2)
    al=DH(3)
    T=np.asarray([math.cos(t),-math.sin(t)*math.cosd(al),math.sin(t)*math.sind(al),a*math.cos(t)],
                        [math.sin(t),math.cos(t)*math.cosd(al),-math.cos(t)*math.sind(al),a*math.sin(t)],
                        [0,math.sind(al),math.cosd(al),d],
                        [0,0,0,1])
    return T



def tf_total(x1,x2,x3,x4,x5,x6,x7):
    #Need to cfm this 
    d1 = 0.34
    d3= 0.4
    d5=0.4
    d7=0.126

    TF1 = tf(np.array[x1,d1,0,-90])
    TF2 = tf(np.array[x2,0,0,-90])
    TF3 = tf(np.array[x3,d3,0,-90])
    TF4 = tf(np.array[x4,0,0,-90])
    TF5 = tf(np.array[x5,d5,0,-90])
    TF6 = tf(np.array[x6,0,0,-90])
    TF7 = tf(np.array[x7,d7,0,-90])

    return(TF1.dot(TF2).dot(TF3).dot(TF4).dot(TF5).dot(TF6).dot(TF7))

